﻿namespace Aplikacja_do_zarzadzania_wydatkami
{
    internal class Program
    {
        private static void Main()
        {
        }
    }
}